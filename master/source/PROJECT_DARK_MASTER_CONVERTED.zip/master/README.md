# PROJECT DARK Master

- Master DB source: `PROJECT_DARK_Master_DB_v4.4_VISUAL_MANIFEST.xlsx`
- Converted CSV sheets: **92**
- Plan source: `PROJECT_DARK_V0.6_PLAN_KO.docx`
- Plan Markdown: `PROJECT_DARK_V0.6_PLAN_KO.md`
- Conversion verification: `CONVERSION_MANIFEST.json`

## Version note
- The uploaded DB is v4.4 VISUAL_MANIFEST and contains 92 sheets.
- The uploaded plan is v0.6. Project history references a later v0.7 plan, so v0.6 must not be labeled the latest-ever plan.

CSV files preserve worksheet cell contents. Formula cells are stored as formula strings beginning with `=`.
